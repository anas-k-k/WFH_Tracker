﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GridEditDemo
{
    public partial class _Default : Page
    {
        private string _connectionString = ConfigurationManager.ConnectionStrings["EmployeeBCPConnection"].ConnectionString;
                   
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GVBind();
            }

        }

        protected void GVBind()
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                StringBuilder sqlBuilder = new StringBuilder("");
                sqlBuilder.Append("select[id], [Manager_Name], [Project_Name],[LOB],[Dept],");
                sqlBuilder.Append("[Work_Effort_No],[Work_Effort_Desc],[WOM],[Associate_Id],");
                sqlBuilder.Append("[Associate_Name], [RFS_City], [Eq_To_WFH], ");
                sqlBuilder.Append("[Ability_To_WFH], [Equipment_Del_Dt],");
                sqlBuilder.Append("[Equipment_Actl_Del_Dt], [Prod_Id],");
                sqlBuilder.Append("[LOB_Per_Trv], [ESA_Location], [RFS_Location],[Buffer_Per_RFS],");
                sqlBuilder.Append("[Manager_Id], [PID], [Offshore_Onsite],[Billability],");
                sqlBuilder.Append("[Dept_Name], [TIC_ID], [Role], [Location_Code],[Location_Code_Desc],");
                sqlBuilder.Append("[SID], [SName] from Tbl_Employee_WFH");
                if (ViewState["filter"] != null)
                {
                   sqlBuilder.Append(ViewState["filter"]);
                }
                SqlCommand cmd = new SqlCommand(sqlBuilder.ToString(), conn);            
                SqlDataAdapter ada = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                ada.Fill(ds);
                GvEmployeeInfo.DataSource = ds;
                GvEmployeeInfo.DataBind();

            }

        }

        protected void GvEmployeeInfo_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GvEmployeeInfo.EditIndex = e.NewEditIndex;
            GVBind();
        }

        protected void GvEmployeeInfo_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int id = Convert.ToInt32(GvEmployeeInfo.DataKeys[e.RowIndex].Value.ToString());
            string wfhOpted = ((DropDownList)GvEmployeeInfo.Rows[e.RowIndex].Cells[4].FindControl("drpWFH")).SelectedValue;
            DateTime dateDelivered = ((Calendar)GvEmployeeInfo.Rows[e.RowIndex].Cells[5].FindControl("calDeliveryDate")).SelectedDate;
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string updateSql = "update Tbl_Employee set Is_WFH='" + wfhOpted + "', Del_Dt='" + dateDelivered + "' where id=" + id;
                SqlCommand cmd = new SqlCommand(updateSql, conn);
                var rowsUpdated = cmd.ExecuteNonQuery();
                if(rowsUpdated>0)
                {
                    GvEmployeeInfo.EditIndex = -1;
                    GVBind();
                }

            }
        }

        protected void GvEmployeeInfo_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GvEmployeeInfo.EditIndex = -1;
            GVBind();
        }

        protected void GvEmployeeInfo_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GvEmployeeInfo.PageIndex = e.NewPageIndex;
            GVBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txtSearch.Text.Trim()))
            {
                lblError.Text = "Please enter search text";
            }
            else
            {
                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    StringBuilder sqlBuilder = new StringBuilder("");
                    int associate_id = 0;
                    int.TryParse(txtSearch.Text.Trim(), out associate_id);
                    conn.Open();
                    string whereClause = string.Empty;
                    sqlBuilder.Append("select[id], [Manager_Name], [Project_Name],[LOB],[Dept],");
                    sqlBuilder.Append("[Work_Effort_No],[Work_Effort_Desc],[WOM],[Associate_Id],");
                    sqlBuilder.Append("[Associate_Name], [RFS_City], [Eq_To_WFH], ");
                    sqlBuilder.Append("[Ability_To_WFH], [Equipment_Del_Dt],");
                    sqlBuilder.Append("[Equipment_Actl_Del_Dt], [Prod_Id],");
                    sqlBuilder.Append("[LOB_Per_Trv], [ESA_Location], [RFS_Location],[Buffer_Per_RFS],");
                    sqlBuilder.Append("[Manager_Id], [PID], [Offshore_Onsite],[Billability],");
                    sqlBuilder.Append("[Dept_Name], [TIC_ID], [Role], [Location_Code],[Location_Code_Desc],");
                    sqlBuilder.Append("[SID], [SName] from Tbl_Employee_WFH");
                   
                    if(associate_id>0)
                    {
                        whereClause = " where Associate_Id=" + txtSearch.Text.Trim();
                    }
                    else
                    {
                        whereClause = " where upper(Associate_Name) like '%" + txtSearch.Text.Trim().ToUpper() + "%'";
                        whereClause += " or upper(Manager_Name) like '%" + txtSearch.Text.Trim().ToUpper() + "%'";
                        whereClause += " or upper(LOB) like '%" + txtSearch.Text.Trim().ToUpper() + "%'";
                        whereClause += " or upper(Project_Name) like '%" + txtSearch.Text.Trim().ToUpper() + "%'";
                    }
                   
                    sqlBuilder.Append(whereClause);
                    SqlCommand cmd = new SqlCommand(sqlBuilder.ToString(), conn);
                    SqlDataAdapter ada = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    ada.Fill(ds);
                    if(ds.Tables[0].Rows.Count> 0)
                    {
                        GvEmployeeInfo.DataSource = ds;
                        GvEmployeeInfo.DataBind();
                        ViewState["filter"] = whereClause;
                        btnClearFilter.Visible = true;
                    }
                    else
                    {
                        lblError.Text = "No record(s) found";

                    }
                  

                }
            }
            
        }

        protected void btnClearFilter_Click(object sender, EventArgs e)
        {
            ViewState["filter"] = null;
            txtSearch.Text = "";
            GVBind();
            btnClearFilter.Visible = false;
        }
    }
}