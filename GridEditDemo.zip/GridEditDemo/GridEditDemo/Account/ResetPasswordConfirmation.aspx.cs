﻿using System.Web.UI;

namespace GridEditDemo.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}