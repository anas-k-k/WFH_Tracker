﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(GridEditDemo.Startup))]
namespace GridEditDemo
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
